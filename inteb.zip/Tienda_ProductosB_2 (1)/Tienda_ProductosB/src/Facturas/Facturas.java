/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturas;

import Cliente.Persona;


// Creación de la clase cliente que hereda de la clase persona
public class Facturas extends Persona {

    private int producto_adquirido;

    public Facturas() {
        this.producto_adquirido = 0;
    }

    public int getProducto_adquirido() {
        return producto_adquirido;
    }

    public void setProducto_adquirido(int producto_adquirido) {
        this.producto_adquirido = producto_adquirido;
    }

    

}
