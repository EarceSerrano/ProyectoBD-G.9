/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Contenedores;

import java.util.LinkedList;
import Clases_Proyecto.Tb_productos;

public class contenedorTb_productos {
    public  static LinkedList Tb_productos = new LinkedList();
}
