/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Contenedores;

import java.util.LinkedList;
import Clases_Proyecto.Clientes;
/**
 *
 * @author Kenneth
 */
public class contenedordetalle_factura {
    public  static LinkedList detalle_factura = new LinkedList();
}
