package Contenedores;
import java.util.LinkedList;
import Clases_Proyecto.Clientes;
/**
 *
 * @author Kenneth
 */
public class ComtenedorClientes {
    public  static LinkedList Clientes = new LinkedList();
}
