/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Proyecto;

/**
 *
 * @author 50664
 */
    public class Tb_material {

        private int ID_material;
        private int unidadPrecio;
        private int unidades;
        private String descripcion; 
        
        public Tb_material() {
        }

 

    public Tb_material(int ID_material, int unidadPrecio, int unidades, String descripcion) {
        this.ID_material = ID_material;
        this.unidadPrecio = unidadPrecio;
        this.unidades = unidades;
        this.descripcion = descripcion;

    }

    public int getID_material() {
        return ID_material;
    }

    public void setID_material(int ID_material) {
        this.ID_material = ID_material;
    }

    public int getUnidadPrecio() {
        return unidadPrecio;
    }

    public void setUnidadPrecio(int unidadPrecio) {
        this.unidadPrecio = unidadPrecio;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    
    }

    
