package Clases_Proyecto;

public class proveedor {
   
private int ID_proveedor; 
private String nombre_p;
private int numero;
private String correo;

 public proveedor () {
    }

    public proveedor(int ID_proveedor, String nombre_p, int numero, String correo) {
        this.ID_proveedor = ID_proveedor;
        this.nombre_p = nombre_p;
        this.numero = numero;
        this.correo = correo;
    }
    /**
     * @return the ID_proveedor
     */
    public int getID_proveedor() {
        return ID_proveedor;
    }

    /**
     * @param ID_proveedor the ID_proveedor to set
     */
    public void setID_proveedor(int ID_proveedor) {
        this.ID_proveedor = ID_proveedor;
    }

    /**
     * @return the nombre_p
     */
    public String getNombre_p() {
        return nombre_p;
    }

    /**
     * @param nombre_p the nombre_p to set
     */
    public void setNombre_p(String nombre_p) {
        this.nombre_p = nombre_p;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

 
 
}


   

   
    
