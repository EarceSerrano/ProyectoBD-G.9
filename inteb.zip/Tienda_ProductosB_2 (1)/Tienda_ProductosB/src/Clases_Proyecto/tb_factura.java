/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Proyecto;

/**
 *
 * @author Esteban
 */
  public class tb_factura {
    private int ID_factura;
    private int ID_cliente;
    private int ID_empleado;
    private String correo;
    private String fecha;

    
    public tb_factura(){
    }

    public tb_factura(int ID_factura, int ID_cliente, int ID_empleado,String correo, String fecha){
        this.ID_factura = ID_factura;
        this.ID_cliente = ID_cliente;
        this.ID_empleado = ID_empleado;
        this.fecha = fecha; 
    }
    
    /**
     * @return the ID_factura
     */
    public int getID_factura() {
        return ID_factura;
    }

    /**
     * @param ID_factura the ID_factura to set
     */
    public void setID_factura(int ID_factura) {
        this.ID_factura = ID_factura;
    }

    /**
     * @return the ID_cliente
     */
    public int getID_cliente() {
        return ID_cliente;
    }

    /**
     * @param ID_cliente the ID_cliente to set
     */
    public void setID_cliente(int ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    /**
     * @return the ID_empleado
     */
    public int getID_empleado() {
        return ID_empleado;
    }

    /**
     * @param ID_empleado the ID_empleado to set
     */
    public void setID_empleado(int ID_empleado) {
        this.ID_empleado = ID_empleado;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}

