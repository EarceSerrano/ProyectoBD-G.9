package Conexion_SQLBD;

import Clases_Proyecto.proveedor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 50664
 */
public class proveedorBD {
    public ArrayList<proveedor> Listproveedor(){
    ArrayList<proveedor> proveedor = new ArrayList();
    
    try{
        Connection cnx = (Connection) DataBaseConexion.getConnection();
        Statement st = cnx.createStatement();
        ResultSet rs = st.executeQuery("SELECT ID_proveedor ,nombre_p ,numero ,correo "
                                                    + " FROM tb_proveedores order by 2");
        while (rs.next()) 
        {
          proveedor pr = new proveedor();
          pr.setID_proveedor(rs.getInt("ID_proveedor"));
          pr.setNombre_p(rs.getString("nombre_p"));
          pr.setNumero(rs.getInt("numero"));
          pr.setCorreo(rs.getString("correo"));
          proveedor.add(pr);    
        }
        
        
    }catch (SQLException ex) {
        System.out.println(ex.getMessage());
        System.out.println("Error en Listado");
    }
        
    return proveedor;
    }

}
