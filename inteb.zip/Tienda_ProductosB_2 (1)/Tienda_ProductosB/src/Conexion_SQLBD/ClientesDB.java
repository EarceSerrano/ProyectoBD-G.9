package Conexion_SQLBD;

import Clases_Proyecto.Clientes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 50664
 */
public class ClientesDB {
    public ArrayList<Clientes>ListClientes(){
                ArrayList<Clientes> cliente = new ArrayList();
                        try{
                               //llamamos ConexionOracle
                               Connection cnx = (Connection) DataBaseConexion.getConnection();
                               //PREPARA EL ESPACION
                               Statement  st = cnx.createStatement();
                               //BOTA EN TABLA O RESULTADOS
                               ResultSet rs = st.executeQuery("SELECT ID_cliente ,nombre ,correo ,telefono "
                                                                          + " FROM  tb_clientes order by 2");
                                                                         
                               while(rs.next())
                                    {
                                       Clientes cl = new Clientes();
                                        cl.setID_cliente(rs.getInt("id_cliente"));
                                        cl.setNombre(rs.getString("nombre"));
                                        cl.setCorreo(rs.getString("correo"));
                                        cl.setTelefono(rs.getInt("telefono"));                                       
                                                 cliente.add(cl);

                                    }


                            }//fin del TRY
                        catch(SQLException ex) {
                                System.out.println(ex.getMessage());
                                System.out.println("no hay errores");
                            }//fin del CATCH
                        return cliente;

            }//fin del metodo ArraList

//    
//    public void insert(Usuario usuario)
//            {
//                try
//                    {
//                        Connection cnx = DataBaseConnect.getConnection();
//                        //permite hacer transacciones eliminar insertar
//                        PreparedStatement pst = cnx.prepareStatement("INSERT INTO  "
//                                + "USUARIO ( CODIGO, NOMBRE, APELLIDO, EDAD) "
//                                + "VALUES( ?, ?, ?, ? )");
//                        pst.setInt(1, usuario.getCodigo());
//                        pst.setString(2, usuario.getNombre());
//                        pst.setString(3, usuario.getApellido());
//                        pst.setInt(4, usuario.getEdad());
//                        
//                        pst.executeUpdate();
//                    
//                    }
//                catch(SQLException ex)
//                     {
//                         System.out.println(ex.getMessage());
//                     }
//            }
//    public void insertarClientes(Clientes cliente){
//        try{
//            Connection cnx = (Connection) DataBaseConexion.getConnection();
//            PreparedStatement pst = cnx.prepareStatement("");
//        } catch(SQLException ex) {
//            System.out.println(ex.getMessage());
//            System.out.println("no hay errores");
//     }
//    }

    //Insertar datos
    
}
