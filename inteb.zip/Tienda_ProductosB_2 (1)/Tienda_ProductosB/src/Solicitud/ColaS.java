/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class ColaS {

    private NodoS inicio;
    private NodoS fin;

    public ColaS() {
        this.inicio = null;
        this.fin = null;
    }

    public NodoS getInicio() {
        return inicio;
    }

    public NodoS getFin() {
        return fin;
    }

//        Método booleano que valida si lista está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }



//    Método que desencola
    public void desencolar() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

//    Método para vaciar la cola
    public void vaciar() {
        while (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

}