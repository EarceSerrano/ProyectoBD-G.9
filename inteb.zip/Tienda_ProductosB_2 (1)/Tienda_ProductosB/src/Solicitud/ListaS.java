/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import Cliente.Cliente;
import Cliente.ListaC;
import Facturas.ListaZ;
import Facturas.NodoZ;
import Productos.Producto;
import Productos.NodoC;
import Productos.ListaProducto;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


// Creación de lista circular doblemente enlazada
public class ListaS {

    ListaC lc = new ListaC();
    ListaZ lv = new ListaZ();
    ColaS cS = new ColaS();
    PilaS pS = new PilaS();
    ListaZ lvDisponibles = new ListaZ();

    private NodoS inicio;
    private NodoS fin;

    public ListaS() {
        this.inicio = null;
        this.fin = null;
    }

//    Método booleano que indica si lista está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }




//    Método que extrae el primer elemento de la lista
    public void extraer() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            fin.setSiguiente(inicio);
            JOptionPane.showMessageDialog(null, "El elemento fue extraído");
        } else {
            JOptionPane.showMessageDialog(null, "No se puede extraer, lista vacía");
        }
    }
}