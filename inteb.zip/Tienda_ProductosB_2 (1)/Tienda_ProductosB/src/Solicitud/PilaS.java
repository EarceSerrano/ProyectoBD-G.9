/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class PilaS {

    private NodoS inicio;

    public PilaS() {
        this.inicio = null;
    }

//    Método booleano que valida si la pila está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public NodoS getCima() {
        return inicio;
    }

    public void setCima(NodoS inicio) {
        this.inicio = inicio;
    }

//  Método para desapilar elemento
    public void desapilar() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            JOptionPane.showMessageDialog(null, "El elemento fue desapilado",
                    "Desapilar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error! No se pudo extraer, "
                    + "Pila Vacía", "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void vaciar() {
        while (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }



    public void desapilar2() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

}
