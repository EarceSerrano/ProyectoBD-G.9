/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frmMenu;

/**
 *
 * @author Kenneth
 */
public class PrincipalContra {
   public static String user = "admin";
    public static String pass = "1234";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    }
    
} 

