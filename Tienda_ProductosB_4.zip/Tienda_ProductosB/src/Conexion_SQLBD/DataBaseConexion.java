/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion_SQLBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

 

/**
*
* @author Kenneth Godinez Chaves
*/
public class DataBaseConexion {

       public static  Connection getConnection()
            {
                try
                    {
                        Class.forName("oracle.jdbc.OracleDriver");
                        String myDB="jdbc:oracle:thin:@localhost:1521:orcl";
                        Connection cnx = DriverManager.getConnection(myDB,"Andy","An2023dy");
                        return cnx;

                    }
                catch(SQLException ex)
                        {
                            System.out.println(ex.getMessage());
                            System.out.println("no hubo coneccion");
                        }
                catch (ClassNotFoundException ex) {
                     Logger.getLogger(DataBaseConexion.class.getName()).log(Level.SEVERE, null, ex);
                      System.out.println("tenemos errores");
                     }
                    return null;
            }
}
