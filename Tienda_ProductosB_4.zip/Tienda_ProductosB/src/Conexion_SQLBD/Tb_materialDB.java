package Conexion_SQLBD;


import Clases_Proyecto.Tb_material;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 50664
 */
public class Tb_materialDB {
    public ArrayList<Tb_material>ListTb_materiales(){
                ArrayList<Tb_material> Tb_materiales = new ArrayList();
                        try{
                               //llamamos ConexionOracle
                               Connection cnx = (Connection) DataBaseConexion.getConnection();
                               //PREPARA EL ESPACION
                               Statement  st = cnx.createStatement();
                               //BOTA EN TABLA O RESULTADOS
                               ResultSet rs = st.executeQuery("SELECT ID_material ,UnidadPrecio ,Unidades ,Descripcion "
                                                                          + " FROM  tb_material order by 2");
                                                                         
                               while(rs.next())
                                    {
                                       Tb_material Tb = new Tb_material();
                                        Tb.setID_material(rs.getInt("ID_material"));
                                        Tb.setUnidadPrecio(rs.getInt("UnidadPrecio")); 
                                        Tb.setUnidades(rs.getInt("Unidades"));
                                        Tb.setDescripcion(rs.getString("Descripcion"));
                                               Tb_materiales.add(Tb);
                                    }


                            }//fin del TRY//fin del TRY
                        catch(SQLException ex) {
                                System.out.println(ex.getMessage());
                                System.out.println("no hay errores");
                            }//fin del CATCH
                        return Tb_materiales;
                        

            }//fin del metodo ArraList

//    
//    public void insert(Usuario usuario)
//            {
//                try
//                    {
//                        Connection cnx = DataBaseConnect.getConnection();
//                        //permite hacer transacciones eliminar insertar
//                        PreparedStatement pst = cnx.prepareStatement("INSERT INTO  "
//                                + "USUARIO ( CODIGO, NOMBRE, APELLIDO, EDAD) "
//                                + "VALUES( ?, ?, ?, ? )");
//                        pst.setInt(1, usuario.getCodigo());
//                        pst.setString(2, usuario.getNombre());
//                        pst.setString(3, usuario.getApellido());
//                        pst.setInt(4, usuario.getEdad());
//                        
//                        pst.executeUpdate();
//                    
//                    }
//                catch(SQLException ex)
//                     {
//                         System.out.println(ex.getMessage());
//                     }
//            }
//    

    //Insertar datos
}
