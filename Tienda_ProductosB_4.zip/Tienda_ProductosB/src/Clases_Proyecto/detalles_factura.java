/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Proyecto;

/**
 *
 * @author Esteban
 */
public class detalles_factura {
    int ID_detalle_factura;
    int ID_factura ;
    int ID_producto ;
    int cantidad ;

    public int getID_detalle_factura() {
        return ID_detalle_factura;
    }

    public void setID_detalle_factura(int ID_detalle_factura) {
        this.ID_detalle_factura = ID_detalle_factura;
    }

    public int getID_factura() {
        return ID_factura;
    }

    public void setID_factura(int ID_factura) {
        this.ID_factura = ID_factura;
    }

    public int getID_producto() {
        return ID_producto;
    }

    public void setID_producto(int ID_producto) {
        this.ID_producto = ID_producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}

    