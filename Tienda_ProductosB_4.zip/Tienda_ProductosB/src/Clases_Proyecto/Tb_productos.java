/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases_Proyecto;

/**
 *
 * @author 50664
 */
public class Tb_productos {
    
    private int ID_producto;
    private String nom_producto;
    private int precio;
    private String descripcion;
    private int ID_categoria;
    private int ID_material;
    private int unidades;
            
    
    public Tb_productos(){
        
    }
    
    public Tb_productos(int ID_producto, String nom_producto, int precio, String descripcion, int ID_categoria, int ID_material ,int unidades){
        this.ID_producto = ID_producto;
        this.nom_producto = nom_producto;
        this.precio = precio;
        this.descripcion = descripcion;
        this.ID_categoria = ID_categoria;
        this.ID_material = ID_material;
        this.unidades = unidades ;        
    }

    public int getID_producto() {
        return ID_producto;
    }

    public void setID_producto(int ID_producto) {
        this.ID_producto = ID_producto;
    }

    public String getNom_producto() {
        return nom_producto;
    }

    public void setNom_producto(String nom_producto) {
        this.nom_producto = nom_producto;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getID_categoria() {
        return ID_categoria;
    }

    public void setID_categoria(int ID_categoria) {
        this.ID_categoria = ID_categoria;
    }

    public int getID_material() {
        return ID_material;
    }

    public void setID_material(int ID_material) {
        this.ID_material = ID_material;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

       
}
