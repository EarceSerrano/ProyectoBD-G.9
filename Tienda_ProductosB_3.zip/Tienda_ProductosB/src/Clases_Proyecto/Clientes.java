package Clases_Proyecto;


public class Clientes {

    private int ID_cliente;
    private  String nombre;
    private String correo;
    private int telefono;

 

    public Clientes() {
    }

 

    public Clientes(int ID_cliente, String nombre, String correo,int telefono) {
        this.ID_cliente = ID_cliente;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;

    }

    /**
     * @return the ID_cliente
     */
    public int getID_cliente() {
        return ID_cliente;
    }

    /**
     * @param ID_cliente the ID_cliente to set
     */
    public void setID_cliente(int ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return the telefono
     */
    public int getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

 
    

 
}
