/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Productos;

/**
 *
 * @author luisdiegoduran
 */
public class NodoC {

    private Producto dato;
    private NodoC siguiente;

    public NodoC() {
        this.siguiente = null;
    }

    /**
     * @return the dato
     */
    public Producto getDato() {
        return dato;
    }

    /**
     * @param dato the dato to set
     */
    public void setDato(Producto dato) {
        this.dato = dato;
    }

    /**
     * @return the siguiente
     */
    public NodoC getSiguiente() {
        return siguiente;
    }

    /**
     * @param siguiente the siguiente to set
     */
    public void setSiguiente(NodoC siguiente) {
        this.siguiente = siguiente;
    }

}
