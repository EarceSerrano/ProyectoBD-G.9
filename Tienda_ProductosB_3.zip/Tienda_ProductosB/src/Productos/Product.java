/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Productos;

/**
 *
 * @author luisdiegoduran
 */
// Creación de la clase persona
public class Product {

    private int IDproducto, numTel;
    private String nombreCompleto, email;

    public Product() {
        this.IDproducto = 0;
        this.nombreCompleto = "";
        this.email = "";
        this.numTel = 0;
    }

    /**
     * @return the cedula
     */
    public int getIDproducto() {
        return IDproducto;
    }

    /**
     * @param IDproducto the cedula to set
     */
    public void setCedula(int IDproducto) {
        this.IDproducto= IDproducto;
    }

    /**
     * @return the numTel
     */
    public int getNumTel() {
        return numTel;
    }

    /**
     * @param numTel the numTel to set
     */
    public void setNumTel(int numTel) {
        this.numTel = numTel;
    }

    /**
     * @return the nombreCompleto
     */
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    /**
     * @param nombreCompleto the nombreCompleto to set
     */
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

}
