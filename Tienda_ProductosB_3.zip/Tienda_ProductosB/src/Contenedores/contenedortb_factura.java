/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Contenedores;

import java.util.LinkedList;
import Clases_Proyecto.Clientes;
/**
 *
 * @author Kenneth
 */
public class contenedortb_factura {
     public  static LinkedList tb_factura = new LinkedList();
}
