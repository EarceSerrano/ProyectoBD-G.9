/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cliente;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author luisdiegoduran
 */
// Creación de lista simple
public class ListaC {

    private NodoC inicio;

    public ListaC() {
        this.inicio = null;
    }

//    Método booleano de lista vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }
// Método booleano si existe cédula

    public boolean existe(int id) {
        if (!vacia()) {
            NodoC aux = inicio;

            while (aux != null) {
                if (aux.getDato().getCedula() == id) {
                    return true;
                } else {
                    aux = aux.getSiguiente();
                }
            }
            return false;
        } else {
            return false;
        }

    }

//    Enlista cliente 
    public void agregar() {
        Cliente c = new Cliente();

        nuevoCliente(c);

        NodoC nuevo = new NodoC();
        nuevo.setDato(c);

        if (vacia()) {
            inicio = nuevo;
        } else if (c.getCedula() < inicio.getDato().getCedula()) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        } else if (inicio.getSiguiente() == null) {
            inicio.setSiguiente(nuevo);
        } else {
            NodoC aux = inicio;
            while (aux.getSiguiente() != null
                    && aux.getSiguiente().getDato().getCedula() < c.getCedula()) {
                aux = aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(nuevo);
        }
    }

    public void extraer() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            JOptionPane.showMessageDialog(null, "Elemento extraído con éxito!");
        } else {
            JOptionPane.showMessageDialog(null, "No se puede extraer! Lista"
                    + " vacía");
        }
    }

//    Imprime la lista de clientes
    public void listaClientes() {
        if (!vacia()) {
            String s = "Lista de los clientes existentes: \nNúmero cédula\t"
                    + "\tNombre cliente\tCorreo electrónico\tNúmero teléfono"
                    + "\tCategoría cliente\n";
            NodoC aux = inicio;
            while (aux != null) {
                s += aux.getDato().getCedula() + "\t\t"
                        + aux.getDato().getNombreCompleto() + "\t\t"
                        + aux.getDato().getEmail() + "\t\t"
                        + aux.getDato().getNumTel() + "\t\t"
                        + aux.getDato().getCategoria() + "\n";
                aux = aux.getSiguiente();
            }
            JOptionPane.showMessageDialog(null,
                    new JTextArea(s),
                    "Lista de reportes",
                    JOptionPane.PLAIN_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "La lista se "
                    + "encuentra vacía, no  es posible mostrar resultados",
                    "Lista Vacía",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

//    Muestra los datos de un cliente en particular
    public void muestraCliente(Cliente c) {
        String s;

        s = "Los datos del cliente con cédula " + c.getCedula() + " son:\n"
                + "Nombre cliente: " + c.getNombreCompleto() + "\n"
                + "Correo electrónico: " + c.getEmail() + "\n"
                + "Número teléfono: " + c.getNumTel() + "\n"
                + "Categoría cliente: " + c.getCategoria();

        JOptionPane.showMessageDialog(null,
                s,
                "Cliente consultado",
                JOptionPane.PLAIN_MESSAGE);

    }

//    Modifica información del cliente
    public void modificarCliente() {
        try {
            int cedula = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el"
                    + " número de cédula de cliente a modificar"));
            if (existe(cedula)) {
                NodoC aux = inicio;
                while (aux != null
                        && aux.getDato().getCedula() != cedula) {
                    aux = aux.getSiguiente();
                }
                int op = 0;
                while (op != 6) {
                    try {
                        op = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Modificar cliente: " + cedula + "\n"
                                + "1. Mostrar información de cliente\n"
                                + "2. Nombre\n"
                                + "3. Correo electrónico\n"
                                + "4. Número teléfono\n"
                                + "5. Categoría\n"
                                + "6. Regresar al módulo de cliente\n"
                                + "Ingrese la opción deseada: \n"));
                    } catch (NumberFormatException e) {
                        op = 0;
                    }

                    switch (op) {
                        case 1:
                            muestraCliente(aux.getDato());
                            break;
                        case 2:
                            aux.getDato().setNombreCompleto(JOptionPane.
                                    showInputDialog("Ingrese el nuevo nombre "
                                            + "completo: "));
                            break;
                        case 3:
                            aux.getDato().setEmail(JOptionPane.
                                    showInputDialog("Ingrese el correo electrónico:"
                                            + " "));
                            break;
                        case 4:
                            nuevoEntero(aux.getDato(), "numTel", "teléfono");
                            break;
                        case 5:
                            nuevoEntero(aux.getDato(), "categoria", "categoria");
                            break;
                        case 6:
                            break;
                        default:
                            JOptionPane.showMessageDialog(null,
                                    "Error! Opción no válida");
                    }
                }

            } else {
                JOptionPane.showMessageDialog(null, "No existe cliente asociado "
                        + "a la cédula " + cedula + ".", "Advertencia",
                        JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Valor no "
                    + "válido, intente de nuevo ingresando un número "
                    + "entero");
            modificarCliente();
        }
    }

//    Método para añadir la cédula de un nuevo cliente, valida que la cédula no
//    hay sido registrada previamente
    public void nuevaCedula(Cliente c) {
        boolean control = true; // Valida que num sea entero
        while (control) {
            try {
                c.setCedula(Integer.parseInt(JOptionPane.
                        showInputDialog("Ingrese la cedula: ")));
                if (!existe(c.getCedula())) {
                    control = false;
                } else {
                    JOptionPane.showMessageDialog(null, ""
                            + "El número de cédula " + c.getCedula() + " ya "
                            + "existe. Intente de nuevo con otro "
                            + "número");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor no "
                        + "válido, intente de nuevo ingresando un número "
                        + "entero");
            }
        }
    }

//    Valida que los valores ingresados sean enteros sino aplica un manejo
//    de excepcion
    public void nuevoEntero(Cliente c, String atributo, String largo) {
        boolean control = true; // Valida que num sea entero
        while (control) {
            try {
                int valor = Integer.parseInt(JOptionPane.
                        showInputDialog("Ingrese el número de " + largo
                                + ": "));

                if (atributo == "numTel") {
                    c.setNumTel(valor);
                    control = false;
                }
                if (atributo == "categoria") {
                    if (valor >= 1 && valor <= 4) {
                        control = false;
                        c.setCategoria(valor);
                    } else {
                        JOptionPane.showMessageDialog(null, "Valor no "
                                + "válido, las categorías son 1, 2, 3 o 4. "
                                + "Intente de nuevo");
                        nuevoEntero(c, atributo, largo);
                    }
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor no "
                        + "válido, intente de nuevo ingresando un número "
                        + "entero");
            }
        }

    }

//    Crea un nuevo cliente
    public void nuevoCliente(Cliente c) {
        nuevaCedula(c);

        c.setNombreCompleto(JOptionPane.showInputDialog("Ingrese el nombre "
                + "completo: "));

        c.setEmail(JOptionPane.showInputDialog("Ingrese el correo electrónico:"
                + " "));

        nuevoEntero(c, "numTel", "teléfono");

        nuevoEntero(c, "categoria", "categoria");

        System.out.println(c.getCedula() + ", " + c.getNombreCompleto() + ", "
                + c.getEmail() + ", " + c.getNumTel() + ", " + c.getCategoria());
    }

//    Enlista elementos que sean digitados directamente y no solicitados al usuario
    public void agregarE(Cliente c) {

        NodoC nuevo = new NodoC();
        nuevo.setDato(c);

        if (vacia()) {
            inicio = nuevo;
        } else if (c.getCedula() < inicio.getDato().getCedula()) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
        } else if (inicio.getSiguiente() == null) {
            inicio.setSiguiente(nuevo);
        } else {
            NodoC aux = inicio;
            while (aux.getSiguiente() != null
                    && aux.getSiguiente().getDato().getCedula() < c.getCedula()) {
                aux = aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(nuevo);
        }
    }

//    método que retorna entero con la categoría del cliente
    public int retornaCategoria(int cedula) {
        NodoC aux = inicio;
        while (aux != null
                && aux.getDato().getCedula() != cedula) {
            aux = aux.getSiguiente();

        }
        return aux.getDato().getCategoria();
    }
}
