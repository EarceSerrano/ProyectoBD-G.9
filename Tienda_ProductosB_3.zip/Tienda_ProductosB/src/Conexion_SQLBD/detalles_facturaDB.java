package Conexion_SQLBD;

import Clases_Proyecto.detalles_factura;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class detalles_facturaDB {
    public ArrayList<detalles_factura> ListDetallesF(){
    ArrayList<detalles_factura> detalleF = new ArrayList();
    
    try{
        Connection cnx = (Connection) DataBaseConexion.getConnection(); //esto depende del nombre que se le agrego a la conexion general(originalmente "DataBaseConnect")
        Statement st = cnx.createStatement();
        ResultSet rs = st.executeQuery("SELECT ID_detalle_factura ,ID_factura ,ID_producto ,cantidad"
        + " FROM detalles_factura ORDER BY 2");
        while(rs.next())
                                    {
                                       detalles_factura fa = new detalles_factura();
                                        fa.setID_detalle_factura(rs.getInt("id_detalleFactura"));
                                        fa.setID_factura(rs.getInt("ID_factura"));
                                        fa.setID_producto(rs.getInt("Id_producto"));
                                        fa.setCantidad(rs.getInt("correo"));                                 
                                                 detalleF.add(fa);

                                    }


                            }//fin del TRY
                        catch(SQLException ex)
                            {
                                System.out.println(ex.getMessage());
                                System.out.println("no hay errores");
                            }//fin del CATCH
                        return detalleF;

            }//fin del metodo ArraList
    
}