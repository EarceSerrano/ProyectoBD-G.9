package Conexion_SQLBD;

import Clases_Proyecto.tb_factura;
import static java.lang.Thread.State.NEW;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class tb_facturaDB {
    public ArrayList<tb_factura>ListFacturas(){
                ArrayList<tb_factura> factura = new ArrayList();
                        try{
                               //llamamos ConexionOracle
                               Connection cnx = (Connection) DataBaseConexion.getConnection(); //esto depende del nombre que se le agrego a la conexion general(originalmente "DataBaseConnect")
                               //PREPARA EL ESPACION
                               Statement  st = cnx.createStatement();
                               //BOTA EN TABLA O RESULTADOS
                               ResultSet rs = st.executeQuery("SELECT ID_factura ,ID_cliente ,ID_empleado ,correo ,fecha "
                                                                          + " FROM  tb_facturas order by 2");
                                                                         
                               while(rs.next())
                                    {
                                       tb_factura tb = new tb_factura();
                                        tb.setID_factura(rs.getInt("id_factura"));
                                        tb.setID_cliente(rs.getInt("nombre"));
                                        tb.setID_empleado(rs.getInt("correo"));
                                        tb.setCorreo(rs.getString("correo"));
                                        tb.setFecha(rs.getString("telefono"));                                       
                                                 factura.add(tb);

                                    }


                            }//fin del TRY
                        catch(SQLException ex)
                            {
                                System.out.println(ex.getMessage());
                                System.out.println("no hay errores");
                            }//fin del CATCH
                        return factura;

            }//fin del metodo ArraList
}