/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import javax.swing.JOptionPane;
import Productos.*;
/**
 *
 * @author luisdiegoduran
 */
public class Menu {

//    Método que contiene el menú principal
    public void mostrarMenuPrincipal() {
        int op = 0;
        ListaS lista = new ListaS();
        lista.completaDatos(); // Invoca método para completar listas con los datos
        while (op != 4) {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Menú Principal\n"
                        + "1. Cliente\n"
                        + "2. Productos\n"
                        + "3. Materiales\n"
                        + "4. Factura\n"
                        + "5 Salir\n"        
                        + "Ingrese la opción deseada: \n"));
            } catch (NumberFormatException e) {
                op = 0;
            }

            switch (op) {
                case 1:
                    menuClientes(lista);
                    break;
                case 2:
                    menuProductos(lista);
                    break;
                case 3:
                    menuMateriales(lista);
                    break;
                case 4:
                    menuFactura(lista);
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error! Opción no válida");
            }
        }
    }

//    Método para el menú de clientes
    public void menuClientes(ListaS l) {
        int op = 0;
        while (op != 5) {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Menú Cliente\n"
                        + "1. Nuevo Cliente\n"
                        + "2. Modificar cliente\n"
                        + "3. Historial solicitudes cliente\n"
                        + "4. Lista de clientes\n"
                        + "5. Menú principal\n"
                        + "Ingrese la opción deseada: \n"));
            } catch (NumberFormatException e) {
                op = 0;
            }

            switch (op) {
                case 1:
                    l.lc.agregar();
                    break;
                case 2:
                    l.lc.modificarCliente();
                    break;
                case 3:
                    l.historialCliente();
                    break;
                case 4:
                    l.lc.listaClientes();
                    break;
                case 5:
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error! Opción no válida");
            }
        }
    }

//    Método para el menú de vehículos
    public void menuProductos(ListaS l) {
        int op = 0;
        while (op != 5) {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Menú Productos\n"
                        + "1. Nuevo Producto\n"
                        + "2. Modificar Producto\n"
                        + "3. Eliminar Producto\n"
                        + "4. Lista de Productos\n"
                        + "5. Menú principal\n"
                        + "Ingrese la opción deseada: \n"));
            } catch (NumberFormatException e) {
                op = 0;
            }

            switch (op) {
                case 1:
                    l.lc.agregar();
                    break;
                case 2:
                    l.lc.modificarCliente();
                    break;
                case 3:
                    l.elimina();
                    break;
                case 4:
                    l.lc.listaClientes();
                    break;
                case 5:
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error! Opción no válida");
            }
        }
    }

//    Menú para las solicitudes
    public void menuMateriales(ListaS l) {
        int op = 0;
        while (op != 6) {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Menú Materiales\n"
                        + "1. Nuevos Materiales\n"
                        + "2. Asignación de Materiales\n"
                        + "3. Devolución de Materiales\n"
                        + "4. Historial de Materiales\n"
                        + "5. Menú principal\n"
                        + "Ingrese la opción deseada: \n"));
            } catch (NumberFormatException e) {
                op = 0;
            }

            switch (op) {
                case 1:
                    l.insertar();
                    break;
                case 3:
                    l.mostrar();
                    break;
                case 4:
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error! Opción no válida");
            }
        }
    }
    
    public void menuFactura(ListaS l) {
        int op = 0;
        while (op != 5) {
            try {
                op = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Menú Factura\n"
                        + "1. Nueva Factura\n"
                        + "2. Modificar Factura\n"
                        + "3. Historial Factura\n"
                        + "4. Menú principal\n"
                        + "Ingrese la opción deseada: \n"));
            } catch (NumberFormatException e) {
                op = 0;
            }

            switch (op) {
                case 1:
                    l.lc.agregar();
                    break;
                case 2:
                    l.lc.modificarCliente();
                    break;
                case 3:
                    l.historialCliente();
                    break;
                case 4:
                    break;
                default:
                    JOptionPane.showMessageDialog(null,
                            "Error! Opción no válida");
            }
        }
    }
}
