/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author luisdiegoduran
 */
public class ColaS {

    private NodoS inicio;
    private NodoS fin;

    public ColaS() {
        this.inicio = null;
        this.fin = null;
    }

    public NodoS getInicio() {
        return inicio;
    }

    public NodoS getFin() {
        return fin;
    }

//        Método booleano que valida si lista está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

//    Método que encola solicitud existente
    public void encolarExistente(Solicitud c) {

        NodoS nuevo = new NodoS();
        nuevo.setElemento(c);

        if (vacia()) {
            inicio = nuevo;
        } else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
    }

//    Método que muestra la cola de solicitudes
    public void mostrar() {
        if (!vacia()) {
            String s = "Lista de solicitudes: \nSolicitud\tCedula\tDías\tPasajeros"
                    + "\tMarca\tModelo\tAño\tEstado\tCategoria\tPlaca\n";
            NodoS aux = new NodoS();
            aux = inicio;
            while (aux != null) {
                s += aux.getElemento().getNumSolicitud() + "\t"
                        + aux.getElemento().getCedula() + "\t"
                        + aux.getElemento().getCantDias() + "\t"
                        + aux.getElemento().getMinPasajeros() + "\t"
                        + aux.getElemento().getMarca() + "\t"
                        + aux.getElemento().getModelo() + "\t"
                        + aux.getElemento().getAnho() + "\t"
                        + aux.getElemento().getEstado() + "\t"
                        + aux.getElemento().getCategoria() + "\t"
                        + aux.getElemento().getPlaca() + "\n";
                aux = aux.getSiguiente();
            }
            JOptionPane.showMessageDialog(null,
                    new JTextArea("La cola de solicitudes pendientes: \n" + s),
                    "Solicitudes sin asignar", JOptionPane.PLAIN_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Todas las solicitudes se atendieron."
                    + "\nNo existen elementos para mostrar", "Sin solicitudes",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

//    Método que desencola
    public void desencolar() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

//    Método para vaciar la cola
    public void vaciar() {
        while (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

//    Método para sacar elemento de la cola
    public void desencolarE(int x) {
        if (!vacia()) {
            if (inicio.getElemento().getNumSolicitud() == x) {
                desencolar();
            } else {
                NodoS anterior = inicio;
                NodoS aux = inicio.getSiguiente();
                while (aux.getElemento() != null
                        && aux.getElemento().getNumSolicitud() != x) {
                    if (aux.getElemento().getNumSolicitud() != x) {
                        anterior = anterior.getSiguiente();
                        aux = aux.getSiguiente();
                    }
                }
                anterior.setSiguiente(aux.getSiguiente());
            }
        }
    }
}
