/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

/**
 *
 * @author luisdiegoduran
 */
// Creación de la clase solicitud
public class Solicitud {

    private int numSolicitud, cedula, anho, cantDias, minPasajeros, categoria,
            placa;
    private String marca, modelo, estado;

    public Solicitud() {
        this.cedula = 0;
        this.cantDias = 0;
        this.minPasajeros = 0;
        this.marca = "";
        this.modelo = "";
        this.anho = 0;
        this.estado = "";
        this.placa = 0;
    }

    /**
     * @return the cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @param cedula the cedula to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the anho
     */
    public int getAnho() {
        return anho;
    }

    /**
     * @param anho the anho to set
     */
    public void setAnho(int anho) {
        this.anho = anho;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the numSolicitud
     */
    public int getNumSolicitud() {
        return numSolicitud;
    }

    /**
     * @param numSolicitud the numSolicitud to set
     */
    public void setNumSolicitud(int numSolicitud) {
        this.numSolicitud = numSolicitud;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the cantDias
     */
    public int getCantDias() {
        return cantDias;
    }

    /**
     * @param cantDias the cantDias to set
     */
    public void setCantDias(int cantDias) {
        this.cantDias = cantDias;
    }

    /**
     * @return the minPasajeros
     */
    public int getMinPasajeros() {
        return minPasajeros;
    }

    /**
     * @param minPasajeros the minPasajeros to set
     */
    public void setMinPasajeros(int minPasajeros) {
        this.minPasajeros = minPasajeros;
    }

    /**
     * @return the categoria
     */
    public int getCategoria() {
        return categoria;
    }

    /**
     * @param categoria the categoria to set
     */
    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    /**
     * @return the placa
     */
    public int getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(int placa) {
        this.placa = placa;
    }

}
