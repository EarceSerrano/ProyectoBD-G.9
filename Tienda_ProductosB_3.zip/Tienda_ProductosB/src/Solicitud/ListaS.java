/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import Cliente.Cliente;
import Cliente.ListaC;
import Facturas.ListaZ;
import Facturas.NodoZ;
import Productos.Producto;
import Productos.NodoC;
import Productos.ListaProducto;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


// Creación de lista circular doblemente enlazada
public class ListaS {

    ListaC lc = new ListaC();
    ListaZ lv = new ListaZ();
    ColaS cS = new ColaS();
    PilaS pS = new PilaS();
    ListaZ lvDisponibles = new ListaZ();

    private NodoS inicio;
    private NodoS fin;

    public ListaS() {
        this.inicio = null;
        this.fin = null;
    }

//    Método booleano que indica si lista está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

//    Método que verifica si una cédula ya se encuentra en la lista de clientes
    public void solicitaValidaCedula(Solicitud c) {
        int id = 0;
        boolean control = true;
        while (control) {
            try {
                id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el "
                        + "número de cédula del cliente:"));
                if (lc.existe(id)) {
                    c.setCedula(id);
                    control = false;
                } else {
                    JOptionPane.showMessageDialog(null, ""
                            + "El número de cédula " + id + " no se "
                            + "encuentra registrado como cliente. Será redirigido"
                            + " al módulo de solicitud de alquiler");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor no "
                        + "válido, intente de nuevo ingresando un número "
                        + "de cédula");
            }
        }
    }

//    Método que valida que el valor ingresado se entero sino aplica manejo de
//    excepciones
    public void validaEntero(Solicitud c, String atributo, String largo) {
        boolean control = true; // Valida que num sea entero
        while (control) {
            try {
                int valor = Integer.parseInt(JOptionPane.
                        showInputDialog("Ingrese el número de " + largo
                                + ": "));

                if (atributo == "anho") {
                    if (valor >= 1990 && valor <= 2023) {
                        control = false;
                        c.setAnho(valor);
                    } else {
                        JOptionPane.showMessageDialog(null, "Valor no "
                                + "válido, el año debe encontrarse dentro del rango"
                                + " 1990 - 2023. "
                                + "Intente de nuevo");
                    }
                }
                if (atributo == "minPasajeros") {
                    if (valor > 0 && valor <= 7) {
                        control = false;
                        c.setMinPasajeros(valor);
                    } else {
                        JOptionPane.showMessageDialog(null, "Valor no "
                                + "válido, la cantidad de pasajeros debe encontrarse"
                                + " en el rango 1 - 7. "
                                + "Intente de nuevo");
                    }
                }
                if (atributo == "cantDias") {
                    if (valor >= 1 && valor <= 31) {
                        control = false;
                        c.setCantDias(valor);
                    } else {
                        JOptionPane.showMessageDialog(null, "Valor no "
                                + "válido, la cantidad de días debe encontrarse"
                                + " en el rango 1 - 31. "
                                + "Intente de nuevo");
                    }
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor no "
                        + "válido, intente de nuevo ingresando un número "
                        + "entero");
            }
        }

    }
//  Método que enlista una nueva solicitud

    public void insertar() {
        Solicitud c = new Solicitud();

        if (fin == null) {
            c.setNumSolicitud(1);
        } else {
            c.setNumSolicitud(fin.getElemento().getNumSolicitud() + 1);
        }

        nuevaSolicitud(c);

        NodoS nuevo = new NodoS();
        nuevo.setElemento(c);

        if (vacia()) {
            inicio = nuevo;
            fin = nuevo;
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else if (c.getNumSolicitud() < inicio.getElemento().getNumSolicitud()) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else if (c.getNumSolicitud() > fin.getElemento().getNumSolicitud()) {
            fin.setSiguiente(nuevo);
            fin = fin.getSiguiente();
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else {
            NodoS aux = inicio;
            while (aux.getSiguiente().getElemento().getNumSolicitud() < c.getNumSolicitud()) {
                aux = aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            nuevo.setAnterior(aux);
            aux.setSiguiente(nuevo);
            nuevo.getSiguiente().setAnterior(nuevo);
        }
    }

//    Método que crea una nueva solicitud
    public void nuevaSolicitud(Solicitud c) {
        solicitaValidaCedula(c);
        validaEntero(c, "cantDias", "días que va a alquilar el vehículo");
        validaEntero(c, "minPasajeros", "pasajeros");

        c.setMarca(JOptionPane.showInputDialog("Ingrese la marca del vehículo"));
        c.setModelo(
                JOptionPane.showInputDialog("Ingrese el modelo"));
        validaEntero(c, "anho", "año");
        c.setEstado("Registrado");
        c.setCategoria(lc.retornaCategoria(c.getCedula()));

    }

//    Enlista elementos que sean digitados directamente y no solicitados al usuario
    public void agregarE(Solicitud c) {
        NodoS nuevo = new NodoS();
        nuevo.setElemento(c);

        if (fin == null) {
            c.setNumSolicitud(1);
        } else {
            c.setNumSolicitud(fin.getElemento().getNumSolicitud() + 1);
        }

        if (vacia()) {
            inicio = nuevo;
            fin = nuevo;
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else if (c.getNumSolicitud() < inicio.getElemento().getNumSolicitud()) {
            nuevo.setSiguiente(inicio);
            inicio = nuevo;
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else if (c.getNumSolicitud() > fin.getElemento().getNumSolicitud()) {
            fin.setSiguiente(nuevo);
            fin = fin.getSiguiente();
            fin.setSiguiente(inicio);
            inicio.setAnterior(fin);
        } else {
            NodoS aux = inicio;
            while (aux.getSiguiente().getElemento().getNumSolicitud() < c.getNumSolicitud()) {
                aux = aux.getSiguiente();
            }
            nuevo.setSiguiente(aux.getSiguiente());
            nuevo.setAnterior(aux);
            aux.setSiguiente(nuevo);
            nuevo.getSiguiente().setAnterior(nuevo);
        }
    }

//    Método que extrae el primer elemento de la lista
    public void extraer() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            fin.setSiguiente(inicio);
            JOptionPane.showMessageDialog(null, "El elemento fue extraído");
        } else {
            JOptionPane.showMessageDialog(null, "No se puede extraer, lista vacía");
        }
    }

//    Método que muestra la lista (historial) de solicitudes
    public void mostrar() {
        String s = "Lista de solicitudes: \nSolicitud\tCedula\tDías\tPasajeros"
                + "\tMarca\tModelo\tAño\tEstado\tCategoria\tPlaca\n";
        NodoS aux = inicio;
        s += aux.getElemento().getNumSolicitud() + "\t"
                + aux.getElemento().getCedula() + "\t"
                + aux.getElemento().getCantDias() + "\t"
                + aux.getElemento().getMinPasajeros() + "\t"
                + aux.getElemento().getMarca() + "\t"
                + aux.getElemento().getModelo() + "\t"
                + aux.getElemento().getAnho() + "\t"
                + aux.getElemento().getEstado() + "\t"
                + aux.getElemento().getCategoria() + "\t"
                + aux.getElemento().getPlaca() + "\n";
        aux = aux.getSiguiente();
        while (aux != inicio) {
            s += aux.getElemento().getNumSolicitud() + "\t"
                    + aux.getElemento().getCedula() + "\t"
                    + aux.getElemento().getCantDias() + "\t"
                    + aux.getElemento().getMinPasajeros() + "\t"
                    + aux.getElemento().getMarca() + "\t"
                    + aux.getElemento().getModelo() + "\t"
                    + aux.getElemento().getAnho() + "\t"
                    + aux.getElemento().getEstado() + "\t"
                    + aux.getElemento().getCategoria() + "\t"
                    + aux.getElemento().getPlaca() + "\n";
            aux = aux.getSiguiente();
        }
        JOptionPane.showMessageDialog(null, new JTextArea(s), "Solicitudes",
                JOptionPane.PLAIN_MESSAGE);
    }

//    Método que elimina una solicitud en particular
    public void elimina() {
        if (!vacia()) {
            int id = Integer.parseInt(JOptionPane.
                    showInputDialog("Ingrese el número de solicitud: "));
            if (inicio.getElemento().getNumSolicitud() == id) {
                inicio = inicio.getSiguiente();
                inicio.setAnterior(fin);
                fin.setSiguiente(inicio);
            } else {
                NodoS anterior, aux;
                anterior = inicio;
                aux = inicio.getSiguiente();

                while (aux != inicio
                        && aux.getElemento().getNumSolicitud() != id) {
                    aux = aux.getSiguiente();
                    anterior = anterior.getSiguiente();
                }
                if (aux != inicio) {
                    anterior.setSiguiente(aux.getSiguiente());
                    fin.setSiguiente(inicio);
                    inicio.setAnterior(fin);
                    JOptionPane.showMessageDialog(null,
                            "Elemento extraído con éxito");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null,
                    "No hay elementos en la lista");
        }
    }

//    Método que encola las solicitudes "Registradas" para establecer prioridades
//    de clientes a la hora de asignarles vehículos
    public void colaSolicitudes() {
        NodoS aux = inicio;
        if (aux.getElemento().getEstado().equals("Registrado")) {
            cS.encolarExistente(aux.getElemento());
        }
        aux = aux.getSiguiente();
        while (aux != inicio) {
            if (aux.getElemento().getEstado().equals("Registrado")) {
                cS.encolarExistente(aux.getElemento());
            }
            aux = aux.getSiguiente();
        }
    }

//    Método que apila solicitudes "Registradas"
    public void pilaSolicitudes() {
        NodoS aux = new NodoS();
        aux = inicio;
        if (aux.getElemento().getEstado().equals("Registrado")) {
            pS.apilarExistente(aux.getElemento());
        }
        aux = aux.getSiguiente();
        while (aux != inicio) {
            if (aux.getElemento().getEstado().equals("Registrado")) {
                pS.apilarExistente(aux.getElemento());
            }
            aux = aux.getSiguiente();
        }
    }

//    Método que muestra el historial de solicitudes de un cliente en particular
    public void historialCliente() {
        int id = 0;
        if (!vacia()) {
            try {
                id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el "
                        + "número de cédula del cliente:"));
                if (lc.existe(id)) {
                    String s = "Lista de solicitudes: \nSolicitud\tCedula\tDías\tPasajeros"
                            + "\tMarca\tModelo\tAño\tEstado\tCategoria\tPlaca\n";
                    NodoS aux = inicio;

                    if (inicio.getElemento().getCedula() == id) {
                        s += aux.getElemento().getNumSolicitud() + "\t"
                                + aux.getElemento().getCedula() + "\t"
                                + aux.getElemento().getCantDias() + "\t"
                                + aux.getElemento().getMinPasajeros() + "\t"
                                + aux.getElemento().getMarca() + "\t"
                                + aux.getElemento().getModelo() + "\t"
                                + aux.getElemento().getAnho() + "\t"
                                + aux.getElemento().getEstado() + "\t"
                                + aux.getElemento().getCategoria() + "\t"
                                + aux.getElemento().getPlaca() + "\n";
                    }
                    aux = aux.getSiguiente();
                    while (aux != inicio) {
                        if (aux.getElemento().getCedula() == id) {
                            s += aux.getElemento().getNumSolicitud() + "\t"
                                    + aux.getElemento().getCedula() + "\t"
                                    + aux.getElemento().getCantDias() + "\t"
                                    + aux.getElemento().getMinPasajeros() + "\t"
                                    + aux.getElemento().getMarca() + "\t"
                                    + aux.getElemento().getModelo() + "\t"
                                    + aux.getElemento().getAnho() + "\t"
                                    + aux.getElemento().getEstado() + "\t"
                                    + aux.getElemento().getCategoria() + "\t"
                                    + aux.getElemento().getPlaca() + "\n";
                        }
                        aux = aux.getSiguiente();
                    }
                    JOptionPane.showMessageDialog(null, new JTextArea(s),
                            "Solicitudes del cliente " + id,
                            JOptionPane.PLAIN_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, ""
                            + "El número de cédula " + id + " no se "
                            + "encuentra registrado como cliente. Será redirigido"
                            + " al módulo de solicitud de alquiler");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Valor no "
                        + "válido, intente de nuevo ingresando un número "
                        + "de cédula");
            }
        } else {
            JOptionPane.showMessageDialog(null, "La lista se "
                    + "encuentra vacía, no  es posible mostrar resultados",
                    "Lista Vacía",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

//    Método que ordena cola de solcitudes por atender (orden se realiza únicamente 
//    por número de solicitud
    public void ordenarCola(boolean asc) {
        ColaS q2 = new ColaS();
        int min = cS.getInicio().getElemento().getNumSolicitud();
        NodoS aux = cS.getInicio();
        while (aux != null) {
            if (min < aux.getElemento().getNumSolicitud()) {
                min = aux.getElemento().getNumSolicitud();
            }
            aux = aux.getSiguiente();
        }

        while (!cS.vacia()) {
            Solicitud s = new Solicitud();
            s.setNumSolicitud(-1);
            cS.encolarExistente(s);
            while (cS.getInicio().getElemento().getNumSolicitud() != s.getNumSolicitud()) {
                if (cS.getInicio().getElemento().getNumSolicitud() < min) {
                    min = cS.getInicio().getElemento().getNumSolicitud();
                }
                cS.encolarExistente(cS.getInicio().getElemento());
                cS.desencolar();
            }
            cS.desencolar();
            while (cS.getInicio().getElemento().getNumSolicitud() != min) {
                cS.encolarExistente(cS.getInicio().getElemento());
                cS.desencolar();
            }
            aux = cS.getInicio();
            while (aux != null) {
                if (min < aux.getElemento().getNumSolicitud()) {
                    min = aux.getElemento().getNumSolicitud();
                }
                aux = aux.getSiguiente();
            }
            q2.encolarExistente(cS.getInicio().getElemento());
            cS.desencolar();
        }
        q2.mostrar();

        if (asc) {
            NodoS cimaAux = q2.getInicio();
            while (cimaAux != null) {
                cS.encolarExistente(cimaAux.getElemento());
                cimaAux = cimaAux.getSiguiente();
            }
        } else {
            PilaS p = new PilaS();
            aux = q2.getInicio();
            while (aux != null) {
                p.apilarExistente(aux.getElemento());
                aux = aux.getSiguiente();
            }
            NodoS aux2 = new NodoS();
            aux2 = p.getCima();
            while (aux2 != null) {
                cS.encolarExistente(aux2.getElemento());
                aux2 = aux2.getSiguiente();
            }
            p = null;
        }
        q2 = null;
    }

//    Método que ordena cola de solcitudes por atender en este caso el orden se
//    realiza por dos criterios, el primero corresponde a la categoría de cliente,
//    es decir, se ubican al inicio las solicitudes de clientes con categoría 4 (de manera)
//    descendente y adicionalmente según el orden de registro (respetando el FIFO)
//    Si se desea ordenar la cola con la categoría ascendente, se requiere ubicar el
//    parámetro en false y se recurre a una pila como pivote para el ordenamiento
    public void ordenarCola2(boolean asc) {
        colaSolicitudes();
        ColaS q2 = new ColaS();
        int min = cS.getInicio().getElemento().getNumSolicitud();
        NodoS aux = cS.getInicio();
        while (aux != null) {
            if (min < aux.getElemento().getNumSolicitud()) {
                min = aux.getElemento().getNumSolicitud();
            }
            aux = aux.getSiguiente();
        }

        while (!cS.vacia()) {
            int categ = 0;
            aux = cS.getInicio();
            while (aux != null) {
                if (categ < aux.getElemento().getCategoria()) {
                    categ = aux.getElemento().getCategoria();
                }
                aux = aux.getSiguiente();
            }
            Solicitud s = new Solicitud();
            s.setNumSolicitud(-1);
            cS.encolarExistente(s);
            while (cS.getInicio().getElemento().getNumSolicitud() != s.getNumSolicitud()) {
                if (cS.getInicio().getElemento().getNumSolicitud() < min
                        && cS.getInicio().getElemento().getCategoria() == categ) {
                    min = cS.getInicio().getElemento().getNumSolicitud();
                }
                cS.encolarExistente(cS.getInicio().getElemento());
                cS.desencolar();
            }
            cS.desencolar();
            while (cS.getInicio().getElemento().getNumSolicitud() != min) {
                cS.encolarExistente(cS.getInicio().getElemento());
                cS.desencolar();
            }
            aux = cS.getInicio();
            while (aux != null) {
                if (min < aux.getElemento().getNumSolicitud()) {
                    min = aux.getElemento().getNumSolicitud();
                }
                aux = aux.getSiguiente();
            }
            if (categ == cS.getInicio().getElemento().getCategoria()) {
                q2.encolarExistente(cS.getInicio().getElemento());
                cS.desencolar();
            }
        }
        q2.mostrar();

        if (asc) {
            NodoS cimaAux = q2.getInicio();
            while (cimaAux != null) {
                cS.encolarExistente(cimaAux.getElemento());
                cimaAux = cimaAux.getSiguiente();
            }
        } else {
            PilaS p = new PilaS();
            aux = q2.getInicio();
            while (aux != null) {
                p.apilarExistente(aux.getElemento());
                aux = aux.getSiguiente();
            }
            NodoS aux2 = new NodoS();
            aux2 = p.getCima();
            while (aux2 != null) {
                cS.encolarExistente(aux2.getElemento());
                aux2 = aux2.getSiguiente();
            }
            p = null;
        }
        q2 = null;
    }

//    Método que se encarga de asignar vehículos a las solicitudes registradas,
//    utiliza el ordenamiento de cola según categoría y número de solicitud.
//    El método está diseñado para asignar las solicitudes según disponibilidad de 
//    vehículos en una misma ejecución


//    Método que valida si existe el número de solicitud
    public boolean existe(int s) {
        NodoS aux = inicio;
        if (aux.getElemento().getNumSolicitud() == s) {
            return true;
        }
        aux = aux.getSiguiente();
        while (aux != inicio) {
            if (aux.getElemento().getNumSolicitud() == s) {
                return true;
            }
            aux = aux.getSiguiente();
        }
        return false;
    }

//    Método que retorna Nodo con solicitud
    public Solicitud retorna(int s) {
        NodoS aux = inicio;
        if (aux.getElemento().getNumSolicitud() == s) {
            return aux.getElemento();
        }
        aux = aux.getSiguiente();
        while (aux != inicio) {
            if (aux.getElemento().getNumSolicitud() == s) {
                return aux.getElemento();
            }
            aux = aux.getSiguiente();
        }
        return null;
    }

//    Método para la devolución de un vehículo alquilado
    

//    Método para registrar datos de clientes, vehiculos y solicitudes
//    al iniciar la ejecución del programa
    public void completaDatos() {
        completaDatosCliente();
        completaDatosFacturas();
        completaDatosSolicitud();
    }

//    Método privado para añadir datos de 10 clientes
    private void completaDatosCliente() {
        Cliente c1 = new Cliente();
        Cliente c2 = new Cliente();
        Cliente c3 = new Cliente();
        Cliente c4 = new Cliente();
        Cliente c5 = new Cliente();
        Cliente c6 = new Cliente();
        Cliente c7 = new Cliente();
        Cliente c8 = new Cliente();
        Cliente c9 = new Cliente();
        Cliente c10 = new Cliente();

        c1.setCedula(942807945);
        c1.setNombreCompleto("Ravi B.");
        c1.setEmail("rbastick0@netvibes.com");
        c1.setNumTel(25830624);
        c1.setCategoria(4);
        lc.agregarE(c1);
        c2.setCedula(938978327);
        c2.setNombreCompleto("Sansone W.");
        c2.setEmail("sweson1@geocities.jp");
        c2.setNumTel(20364828);
        c2.setCategoria(2);
        lc.agregarE(c2);
        c3.setCedula(519825706);
        c3.setNombreCompleto("Clotilda A.");
        c3.setEmail("cakhurst2@i2i.jp");
        c3.setNumTel(25094828);
        c3.setCategoria(4);
        lc.agregarE(c3);
        c4.setCedula(920514283);
        c4.setNombreCompleto("Ruth S.");
        c4.setEmail("rstrond3@sohu.com");
        c4.setNumTel(29074809);
        c4.setCategoria(3);
        lc.agregarE(c4);
        c5.setCedula(592817377);
        c5.setNombreCompleto("Gusta C.");
        c5.setEmail("gchapple4@tiny.cc");
        c5.setNumTel(22346738);
        c5.setCategoria(2);
        lc.agregarE(c5);
        c6.setCedula(318944301);
        c6.setNombreCompleto("Kathrine M.");
        c6.setEmail("kmccrossan5@gmpg.org");
        c6.setNumTel(22932572);
        c6.setCategoria(3);
        lc.agregarE(c6);
        c7.setCedula(135079700);
        c7.setNombreCompleto("Odella V.");
        c7.setEmail("ovinden6@seesaa.net");
        c7.setNumTel(20755639);
        c7.setCategoria(1);
        lc.agregarE(c7);
        c8.setCedula(131959206);
        c8.setNombreCompleto("Ranique P.");
        c8.setEmail("rpietruschka7@uol.com.br");
        c8.setNumTel(23550821);
        c8.setCategoria(2);
        lc.agregarE(c8);
        c9.setCedula(586410084);
        c9.setNombreCompleto("Marsiella S.");
        c9.setEmail("msprague8@blogspot.com");
        c9.setNumTel(22184794);
        c9.setCategoria(4);
        lc.agregarE(c9);
        c10.setCedula(943573850);
        c10.setNombreCompleto("Clair G.");
        c10.setEmail("cgergolet9@angelfire.com");
        c10.setNumTel(21251846);
        c10.setCategoria(1);
        lc.agregarE(c10);

    }
    
    private void completaDatosFacturas() {
        Cliente c1 = new Cliente();
        Cliente c2 = new Cliente();
        Cliente c3 = new Cliente();
        Cliente c4 = new Cliente();
        Cliente c5 = new Cliente();
        Cliente c6 = new Cliente();
        Cliente c7 = new Cliente();
        Cliente c8 = new Cliente();
        Cliente c9 = new Cliente();
        Cliente c10 = new Cliente();

        c1.setCedula(942807945);
        c1.setNombreCompleto("Ravi B.");
        c1.setEmail("rbastick0@netvibes.com");
        c1.setNumTel(25830624);
        c1.setCategoria(4);
        lc.agregarE(c1);
        c2.setCedula(938978327);
        c2.setNombreCompleto("Sansone W.");
        c2.setEmail("sweson1@geocities.jp");
        c2.setNumTel(20364828);
        c2.setCategoria(2);
        lc.agregarE(c2);
        c3.setCedula(519825706);
        c3.setNombreCompleto("Clotilda A.");
        c3.setEmail("cakhurst2@i2i.jp");
        c3.setNumTel(25094828);
        c3.setCategoria(4);
        lc.agregarE(c3);
        c4.setCedula(920514283);
        c4.setNombreCompleto("Ruth S.");
        c4.setEmail("rstrond3@sohu.com");
        c4.setNumTel(29074809);
        c4.setCategoria(3);
        lc.agregarE(c4);
        c5.setCedula(592817377);
        c5.setNombreCompleto("Gusta C.");
        c5.setEmail("gchapple4@tiny.cc");
        c5.setNumTel(22346738);
        c5.setCategoria(2);
        lc.agregarE(c5);
        c6.setCedula(318944301);
        c6.setNombreCompleto("Kathrine M.");
        c6.setEmail("kmccrossan5@gmpg.org");
        c6.setNumTel(22932572);
        c6.setCategoria(3);
        lc.agregarE(c6);
        c7.setCedula(135079700);
        c7.setNombreCompleto("Odella V.");
        c7.setEmail("ovinden6@seesaa.net");
        c7.setNumTel(20755639);
        c7.setCategoria(1);
        lc.agregarE(c7);
        c8.setCedula(131959206);
        c8.setNombreCompleto("Ranique P.");
        c8.setEmail("rpietruschka7@uol.com.br");
        c8.setNumTel(23550821);
        c8.setCategoria(2);
        lc.agregarE(c8);
        c9.setCedula(586410084);
        c9.setNombreCompleto("Marsiella S.");
        c9.setEmail("msprague8@blogspot.com");
        c9.setNumTel(22184794);
        c9.setCategoria(4);
        lc.agregarE(c9);
        c10.setCedula(943573850);
        c10.setNombreCompleto("Clair G.");
        c10.setEmail("cgergolet9@angelfire.com");
        c10.setNumTel(21251846);
        c10.setCategoria(1);
        lc.agregarE(c10);

    }

//    Método privado para añadir datos de 10 solicitudes
    private void completaDatosSolicitud() {
        Solicitud s1 = new Solicitud();
        Solicitud s2 = new Solicitud();
        Solicitud s3 = new Solicitud();
        Solicitud s4 = new Solicitud();
        Solicitud s5 = new Solicitud();
        Solicitud s6 = new Solicitud();
        Solicitud s7 = new Solicitud();
        Solicitud s8 = new Solicitud();
        Solicitud s9 = new Solicitud();
        Solicitud s10 = new Solicitud();

        s1.setNumSolicitud(1);
        s1.setCedula(318944301);
        s1.setCantDias(4);
        s1.setMinPasajeros(5);
        s1.setMarca("Kia");
        s1.setModelo("Sorento");
        s1.setAnho(2020);
        s1.setEstado("Alquilado");
        s1.setCategoria(3);
        s1.setPlaca(841703);
        agregarE(s1);
        s2.setNumSolicitud(2);
        s2.setCedula(938978327);
        s2.setCantDias(3);
        s2.setMinPasajeros(4);
        s2.setMarca("Mazda");
        s2.setModelo("Cx9");
        s2.setAnho(2011);
        s2.setEstado("Registrado");
        s2.setCategoria(2);
        s2.setPlaca(0);
        agregarE(s2);
        s3.setNumSolicitud(3);
        s3.setCedula(942807945);
        s3.setCantDias(7);
        s3.setMinPasajeros(3);
        s3.setMarca("Mitsubishi");
        s3.setModelo("Montero Sport");
        s3.setAnho(2018);
        s3.setEstado("Registrado");
        s3.setCategoria(4);
        s3.setPlaca(0);
        agregarE(s3);
        s4.setNumSolicitud(4);
        s4.setCedula(318944301);
        s4.setCantDias(3);
        s4.setMinPasajeros(7);
        s4.setMarca("Mitsubishi");
        s4.setModelo("Outlander");
        s4.setAnho(2023);
        s4.setEstado("Cancelado");
        s4.setCategoria(3);
        s4.setPlaca(0);
        agregarE(s4);
        s5.setNumSolicitud(5);
        s5.setCedula(943573850);
        s5.setCantDias(3);
        s5.setMinPasajeros(7);
        s5.setMarca("Toyota");
        s5.setModelo("4runner");
        s5.setAnho(2022);
        s5.setEstado("Registrado");
        s5.setCategoria(1);
        s5.setPlaca(0);
        agregarE(s5);
        s6.setNumSolicitud(6);
        s6.setCedula(938978327);
        s6.setCantDias(5);
        s6.setMinPasajeros(6);
        s6.setMarca("Toyota");
        s6.setModelo("Land Cruiser");
        s6.setAnho(2012);
        s6.setEstado("Finalizado");
        s6.setCategoria(2);
        s6.setPlaca(623143);
        agregarE(s6);
        s7.setNumSolicitud(7);
        s7.setCedula(592817377);
        s7.setCantDias(5);
        s7.setMinPasajeros(6);
        s7.setMarca("Mazda");
        s7.setModelo("Cx9");
        s7.setAnho(2018);
        s7.setEstado("Registrado");
        s7.setCategoria(2);
        s7.setPlaca(0);
        agregarE(s7);
        s8.setNumSolicitud(8);
        s8.setCedula(586410084);
        s8.setCantDias(6);
        s8.setMinPasajeros(7);
        s8.setMarca("Mitsubishi");
        s8.setModelo("Montero Sport");
        s8.setAnho(2020);
        s8.setEstado("Registrado");
        s8.setCategoria(4);
        s8.setPlaca(0);
        agregarE(s8);
        s9.setNumSolicitud(9);
        s9.setCedula(135079700);
        s9.setCantDias(1);
        s9.setMinPasajeros(3);
        s9.setMarca("Mitsubishi");
        s9.setModelo("Outlander");
        s9.setAnho(2022);
        s9.setEstado("Alquilado");
        s9.setCategoria(1);
        s9.setPlaca(593447);
        agregarE(s9);
        s10.setNumSolicitud(10);
        s10.setCedula(920514283);
        s10.setCantDias(4);
        s10.setMinPasajeros(1);
        s10.setMarca("Toyota");
        s10.setModelo("Land Cruiser");
        s10.setAnho(2015);
        s10.setEstado("Finalizado");
        s10.setCategoria(3);
        s10.setPlaca(949786);
        agregarE(s10);
    }

}
