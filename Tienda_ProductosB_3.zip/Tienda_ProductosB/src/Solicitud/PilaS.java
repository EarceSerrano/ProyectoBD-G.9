/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Solicitud;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author Leonardo Brenes Seas, Luis Diego Durán Villalobos, Kenneth Godínez
 * Chaves
 */
public class PilaS {

    private NodoS inicio;

    public PilaS() {
        this.inicio = null;
    }

//    Método booleano que valida si la pila está vacía
    public boolean vacia() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public NodoS getCima() {
        return inicio;
    }

    public void setCima(NodoS inicio) {
        this.inicio = inicio;
    }

//  Método para desapilar elemento
    public void desapilar() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
            JOptionPane.showMessageDialog(null, "El elemento fue desapilado",
                    "Desapilar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error! No se pudo extraer, "
                    + "Pila Vacía", "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
        }
    }

//    Método para mostrar elementos en la pila
    public void mostrarElementos() {
        if (!vacia()) {
            String s = "Lista de solicitudes: \nSolicitud\tCedula\tDías\tPasajeros"
                    + "\tMarca\tModelo\tAño\tEstado\tCategoria\tPlaca\n";
            NodoS aux = new NodoS();
            aux = inicio;
            while (aux != null) {
                s += aux.getElemento().getNumSolicitud() + "\t"
                        + aux.getElemento().getCedula() + "\t"
                        + aux.getElemento().getCantDias() + "\t"
                        + aux.getElemento().getMinPasajeros() + "\t"
                        + aux.getElemento().getMarca() + "\t"
                        + aux.getElemento().getModelo() + "\t"
                        + aux.getElemento().getAnho() + "\t"
                        + aux.getElemento().getEstado() + "\t"
                        + aux.getElemento().getCategoria() + "\t"
                        + aux.getElemento().getPlaca() + "\n";
                aux = aux.getSiguiente();
            }
            JOptionPane.showMessageDialog(null,
                    new JTextArea("La pila de solicitudes pendientes: \n" + s),
                    "Solicitudes sin asignar", JOptionPane.PLAIN_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Todas las solicitudes se atendieron."
                    + "\nNo existen elementos para mostrar", "Sin solicitudes",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void vaciar() {
        while (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

//    Método para apilar solicitudes ya existentes
    public void apilarExistente(Solicitud c) {

        NodoS nuevo = new NodoS();
        nuevo.setElemento(c);

        if (!vacia()) {
            nuevo.setSiguiente(inicio);
        }
        inicio = nuevo;
    }

    public void desapilar2() {
        if (!vacia()) {
            inicio = inicio.getSiguiente();
        }
    }

}
